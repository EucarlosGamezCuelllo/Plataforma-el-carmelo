# Contenidos interactivos H5P

Exporta cada actividad desde Moodle (*Banco de contenido → ⋮ → Descargar*) y guárdala como `.h5p`.

| Archivo | Tipo | Nivel de Bloom | Curso |
|---|---|---|---|
| `leccion_<tema>.h5p` | Lección interactiva | Comprender | `[COMPLETAR]` |
| `arrastrar_<tema>.h5p` | Arrastrar y soltar | Aplicar | `[COMPLETAR]` |
| `linea_tiempo_<tema>.h5p` | Línea de tiempo | Recordar | `[COMPLETAR]` |
