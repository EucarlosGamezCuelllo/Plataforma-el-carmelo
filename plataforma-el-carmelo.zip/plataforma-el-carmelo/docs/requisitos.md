# Requisitos y trazabilidad

Resumen del análisis de requerimientos del documento maestro (15 historias de usuario, 23 requisitos funcionales,
12 no funcionales). El detalle completo está en las Tablas 23 a 28 del documento.

## Historias de usuario y asignación a sprints
| Sprint | Historias | Incremento |
|---|---|---|
| 3 | – | Requisitos priorizados y servidor de pruebas |
| 4 | – | Diseño integral aprobado |
| 5 | HU01, HU02, HU08, HU13 | Plataforma base, roles, tema, carga masiva, curso plantilla y primer curso |
| 6 | HU03, HU04, HU09, HU10 | Segundo curso, banco de preguntas, H5P y descarga en la app móvil |
| 7 | HU05, HU06, HU14 | Tercer curso, tareas, foros, respaldos y pruebas de seguridad |
| 8 | HU07, HU11, HU12, HU15 | Calificaciones, rúbricas, informes, ajustes y manual |

## Historias
| ID | Historia | Prioridad |
|---|---|---|
| HU01 | Ingresar con usuario y contraseña desde el celular o el computador | Debe |
| HU02 | Ver mis cursos, fechas de entrega y progreso | Debe |
| HU03 | Descargar guías y recursos para estudiar sin conexión continua | Debe |
| HU04 | Resolver cuestionarios y ver el resultado de inmediato | Debe |
| HU05 | Entregar tareas desde el celular | Debe |
| HU06 | Participar en foros y recibir avisos | Debería |
| HU07 | Consultar calificaciones y retroalimentación | Debe |
| HU08 | (Docente) Crear y organizar cursos por unidades | Debe |
| HU09 | (Docente) Publicar recursos (PDF, video, H5P, enlaces) | Debe |
| HU10 | (Docente) Crear cuestionarios con banco de preguntas | Debe |
| HU11 | (Docente) Calificar con rúbricas y retroalimentar | Debería |
| HU12 | (Docente) Ver reportes de participación y desempeño | Debería |
| HU13 | (Administrador) Gestionar usuarios, roles y matrículas, incluso de forma masiva | Debe |
| HU14 | (Administrador) Copias de respaldo automáticas y restauración | Debe |
| HU15 | (Directivo) Consultar reportes de uso de la plataforma | Debería |

> Copia aquí los requisitos funcionales (RF01–RF23) y no funcionales (RNF01–RNF12) de las Tablas 25 y 26
> del documento maestro, y la matriz de trazabilidad de la Tabla 28.
