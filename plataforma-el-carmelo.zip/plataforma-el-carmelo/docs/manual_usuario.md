# Manual de usuario

## Estudiante
1. **Ingresar:** abre la dirección de la plataforma desde el celular o el computador e inicia sesión con tu usuario.
2. **Ver mis cursos:** en el tablero aparecen tus cursos, fechas de entrega y progreso.
3. **Descargar contenidos para estudiar sin internet:** instala Moodle App, abre el curso y pulsa el ícono de descarga.
4. **Resolver un cuestionario:** entra a la actividad, responde y revisa tu resultado y la retroalimentación.
5. **Entregar una tarea:** abre la tarea, adjunta el archivo o escribe el texto y pulsa *Guardar cambios*.
6. **Foros y avisos:** participa en el foro del curso y lee el foro de novedades.
7. **Calificaciones:** consulta *Calificaciones* para ver tus notas y comentarios.

## Docente
1. **Crear un curso:** solicita al administrador o duplica el curso plantilla de tu área.
2. **Organizar unidades:** usa la estructura de la plantilla (presentación, recursos, actividad H5P, cuestionario, tarea).
3. **Publicar recursos:** PDF, videos livianos, enlaces y contenidos H5P.
4. **Banco de preguntas:** crea categorías por nivel de Bloom y reutiliza las preguntas en varios cuestionarios.
5. **Calificar con rúbrica:** configura la rúbrica en la tarea y retroalimenta.
6. **Informes:** consulta participación, entregas y calificaciones por estudiante.

## Administrador
1. **Usuarios y roles:** carga masiva con CSV y asignación de roles (administrador, docente, estudiante, directivo).
2. **Copias de respaldo:** verifica que se ejecute el respaldo diario y prueba la restauración.
3. **Seguridad:** política de contraseñas, actualizaciones y revisión de registros.
4. **Informes de uso:** reportes por curso y por periodo para la dirección.

> Agrega capturas de pantalla en `docs/figuras/capturas/` y enlázalas aquí.
