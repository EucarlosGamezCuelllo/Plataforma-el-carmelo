# Guía de instalación y configuración

> Probada sobre Ubuntu Server LTS. Verifica en https://docs.moodle.org los requisitos exactos (versión de PHP,
> extensiones y base de datos) de la versión de Moodle que instales.

## 1. Requisitos previos
- Servidor virtual Linux con acceso `sudo` y puertos 80 y 443 abiertos.
- Un dominio apuntando a la IP del servidor.
- Al menos 2 vCPU, 4 GB de RAM y 40 GB de disco (ajustar según el número de usuarios).

## 2. Preparar el servidor
```bash
sudo bash moodle-config/instalar_servidor.sh
```
El script instala Apache, PHP con las extensiones requeridas, MariaDB y Certbot, y crea la base de datos.
Edita las variables del inicio (dominio, nombre de base de datos y usuario) **antes** de ejecutarlo.

## 3. Descargar Moodle
El script clona la rama estable indicada en la variable `MOODLE_BRANCH`. Confirma en https://download.moodle.org
cuál es la versión LTS vigente y ajusta la variable si es necesario.

## 4. Asistente web de instalación
1. Abre `https://TU_DOMINIO` y sigue el asistente (idioma español).
2. Directorio de datos: `/var/moodledata`.
3. Base de datos: MariaDB, con los datos creados por el script.
4. Crea la cuenta de administrador con una contraseña robusta.

## 5. Ajustes iniciales
Aplica la lista de `moodle-config/ajustes.md`.

## 6. Complementos
Instala los complementos de `moodle-config/plugins.md` desde *Administración del sitio → Complementos*.

## 7. Cursos y contenidos
- Restaura los `.mbz` de la carpeta `courses/` (*Administración → Cursos → Restaurar curso*).
- Importa los contenidos `.h5p` de la carpeta `h5p/` al banco de contenido.

## 8. Usuarios
Carga masiva con la plantilla `scripts/plantilla_usuarios.csv`
(*Administración → Usuarios → Cuentas → Subir usuarios*).

## 9. Copias de respaldo
Programa `scripts/respaldo.sh` en `cron` (ver encabezado del script).
Verifica la restauración con `scripts/restaurar.sh` en un entorno de pruebas.

## 10. Acceso móvil
Habilita el servicio web móvil (ver `ajustes.md`) y prueba con Moodle App:
ingreso, descarga de un curso y consulta sin conexión.

## Solución de problemas
| Síntoma | Posible causa | Qué revisar |
|---|---|---|
| Error de base de datos en el asistente | Usuario o contraseña incorrectos | Datos del script de instalación |
| Página lenta | Falta de caché o recursos pesados | Caché de Moodle, tamaño de imágenes y videos |
| Moodle App no conecta | Servicio móvil o certificado | Ajustes → Servicios web; certificado SSL válido |
