# Guía de transición digital (borrador)

Ruta replicable para otras instituciones públicas. Completa con la experiencia del piloto.

1. **Diagnóstico:** inventario de dispositivos, conectividad y competencias digitales (instrumentos en el documento maestro).
2. **Decisión tecnológica:** matriz ponderada para elegir el LMS según costo, baja conectividad, acceso móvil y mantenimiento.
3. **Alistamiento:** servidor, dominio, certificado, respaldos y roles.
4. **Diseño pedagógico:** plantilla de curso con ADDIE y Bloom.
5. **Capacitación docente:** talleres prácticos y acompañamiento durante el piloto.
6. **Piloto:** cuatro semanas con grupos y áreas priorizadas.
7. **Evaluación:** SUS, TAM, ICDA, registros de la plataforma y entrevistas.
8. **Ajustes y escalamiento:** corrección de hallazgos y ampliación gradual a más áreas.

## Lecciones aprendidas
`[COMPLETAR con los resultados del piloto]`
