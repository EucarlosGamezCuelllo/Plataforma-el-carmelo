# Documentación

| Archivo | Propósito |
|---|---|
| `Documento_maestro_Fase4.docx` / `.pdf` | Documento maestro del proyecto |
| `arquitectura_y_diseno.md` | Arquitectura, estructura pedagógica y decisiones de diseño |
| `guia_instalacion.md` | Instalación y configuración del servidor y de Moodle |
| `manual_usuario.md` | Manual para docentes, estudiantes y administrador |
| `requisitos.md` | Historias de usuario, requisitos y trazabilidad |
| `guia_transicion_digital.md` | Ruta replicable para otras instituciones |
| `figuras/` | Figuras del diseño (arquitectura, navegación, plantilla de curso, modelo de datos, maquetas) |
