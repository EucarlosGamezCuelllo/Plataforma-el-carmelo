# Arquitectura y diseño integral

Fuente: documento maestro (sección «Diseño preliminar del prototipo» y «Desarrollo del prototipo funcional»).

## Principios
- **Baja conectividad primero:** recursos livianos, descargables y de consulta sin conexión continua.
- **Celular primero:** diseño adaptable y uso de Moodle App.
- **Simplicidad:** navegación de tres clics o menos.
- **Pedagogía antes que tecnología:** cursos con ADDIE y Taxonomía de Bloom.
- **Seguridad y privacidad por diseño:** roles de mínimo privilegio, cifrado y datos mínimos.
- **Sostenibilidad:** software libre y documentación para que la institución pueda replicar.

## Pila tecnológica por capas
| Capa | Componente |
|---|---|
| Presentación | Navegador web y Moodle App (celular) |
| Aplicación | Moodle (LMS) + H5P + tema institucional |
| Servidor web | Apache o Nginx con SSL/TLS |
| Lenguaje | PHP |
| Datos | MariaDB o MySQL; carpeta `moodledata` |
| Infraestructura | Servidor virtual Linux en la nube, copias de respaldo diarias |
| Control de versiones | GitHub |

## Decisiones de diseño integral
| Dimensión | Decisión | Implementación | Requisitos |
|---|---|---|---|
| Tecnológica | Pila por capas con Moodle sobre Linux | Moodle en servidor en la nube, dominio y SSL/TLS | RNF07 a RNF10 |
| Pedagógica | Plantilla de curso ADDIE + Bloom | Curso plantilla duplicable, banco de preguntas por nivel, H5P | RF06 a RF08; RF10 a RF16 |
| Interfaz | Diseño adaptable, ≤ 3 clics | Tema institucional y tablero personal | RNF03 a RNF05 |
| Datos | Modelo apoyado en la BD de Moodle | Roles, cohortes y matrícula masiva por CSV | RF04, RF05, RF19, RF20 |
| Seguridad | Mínimo privilegio, datos de menores | Roles, política de contraseñas, respaldos | RF21; RNF08, RNF09 |
| Conectividad | Estrategias de baja conectividad | Descarga en Moodle App, recursos livianos | RF09; RNF01, RNF02 |

## Estructura pedagógica de cada curso
Cada unidad incluye: presentación, recursos descargables, actividades H5P, cuestionario con retroalimentación
inmediata y una tarea de aplicación o creación, cubriendo los seis niveles de Bloom (recordar, comprender, aplicar,
analizar, evaluar y crear).

## Figuras
Ver la carpeta `figuras/`.
