# Tema institucional

Coloca aquí la carpeta del tema personalizado (por ejemplo `theme/elcarmelo/`) con:
- logo e imágenes,
- archivo de estilos (SCSS/CSS),
- `version.php` y `lang/`.

Si usaste un tema existente de Moodle y solo cambiaste ajustes, documenta aquí:

| Dato | Valor |
|---|---|
| Tema base | `[COMPLETAR]` |
| Colores principales | `[COMPLETAR]` |
| Tipografía | `[COMPLETAR]` |
| Ajustes modificados | `[COMPLETAR]` |

Guía de estilo de referencia: Tabla 30 del documento maestro.
