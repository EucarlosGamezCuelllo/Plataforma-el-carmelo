# Configuración de Moodle

| Archivo | Uso |
|---|---|
| `instalar_servidor.sh` | Prepara Apache, PHP, MariaDB y Certbot, y descarga Moodle |
| `ajustes.md` | Lista de ajustes aplicados desde el panel de administración |
| `plugins.md` | Complementos instalados y su versión |
| `config-ejemplo.php` | Ejemplo de `config.php` **sin claves** |

El `config.php` real nunca se sube al repositorio.
