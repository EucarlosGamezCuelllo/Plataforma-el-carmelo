<?php
// EJEMPLO de config.php SIN CLAVES. El archivo real se llama config.php y NO se sube a GitHub.
unset($CFG);
global $CFG;
$CFG = new stdClass();

$CFG->dbtype    = 'mariadb';
$CFG->dblibrary = 'native';
$CFG->dbhost    = 'localhost';
$CFG->dbname    = 'moodle';
$CFG->dbuser    = 'moodleuser';
$CFG->dbpass    = 'CAMBIAR_ESTA_CLAVE';
$CFG->prefix    = 'mdl_';
$CFG->dboptions = array('dbpersist' => 0, 'dbport' => '', 'dbsocket' => '', 'dbcollation' => 'utf8mb4_unicode_ci');

$CFG->wwwroot   = 'https://plataforma.ejemplo.edu.co';
$CFG->dataroot  = '/var/moodledata';
$CFG->admin     = 'admin';
$CFG->directorypermissions = 0770;

require_once(__DIR__ . '/lib/setup.php');
