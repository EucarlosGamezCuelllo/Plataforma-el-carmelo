#!/usr/bin/env bash
# Prepara un servidor Ubuntu Server LTS para Moodle.
# Uso: sudo bash instalar_servidor.sh
# IMPORTANTE: edita las variables antes de ejecutar y NO subas este archivo con contraseñas reales.
set -euo pipefail

DOMINIO="plataforma.ejemplo.edu.co"       # <-- cambiar
CORREO_ADMIN="admin@ejemplo.edu.co"        # <-- cambiar (para el certificado)
DB_NAME="moodle"
DB_USER="moodleuser"
DB_PASS="CAMBIAR_ESTA_CLAVE"               # <-- cambiar; no subir a GitHub
MOODLE_BRANCH="MOODLE_405_STABLE"          # <-- verificar la rama LTS vigente en download.moodle.org
WEBROOT="/var/www/moodle"
DATAROOT="/var/moodledata"

if [[ $EUID -ne 0 ]]; then echo "Ejecuta como root (sudo)."; exit 1; fi
if [[ "$DB_PASS" == "CAMBIAR_ESTA_CLAVE" ]]; then echo "Cambia DB_PASS antes de continuar."; exit 1; fi

apt-get update
apt-get install -y apache2 mariadb-server git unzip curl certbot python3-certbot-apache \
  php php-cli php-mysql php-xml php-mbstring php-curl php-zip php-gd php-intl php-soap php-xmlrpc \
  php-ldap php-opcache libapache2-mod-php

# Base de datos
mysql -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME} DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -e "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
mysql -e "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost'; FLUSH PRIVILEGES;"

# Moodle
if [[ ! -d "$WEBROOT" ]]; then
  git clone -b "$MOODLE_BRANCH" --depth 1 https://github.com/moodle/moodle.git "$WEBROOT"
fi
mkdir -p "$DATAROOT"
chown -R www-data:www-data "$DATAROOT"
chmod -R 770 "$DATAROOT"

# Apache
cat > /etc/apache2/sites-available/moodle.conf <<EOF
<VirtualHost *:80>
    ServerName ${DOMINIO}
    DocumentRoot ${WEBROOT}
    <Directory ${WEBROOT}>
        Options FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/moodle_error.log
    CustomLog \${APACHE_LOG_DIR}/moodle_access.log combined
</VirtualHost>
EOF
a2ensite moodle.conf
a2enmod rewrite
a2dissite 000-default.conf || true
systemctl reload apache2

# Ajustes de PHP recomendados por Moodle
for ini in /etc/php/*/apache2/php.ini /etc/php/*/cli/php.ini; do
  sed -i 's/^;\?max_input_vars.*/max_input_vars = 5000/' "$ini"
  sed -i 's/^upload_max_filesize.*/upload_max_filesize = 100M/' "$ini"
  sed -i 's/^post_max_size.*/post_max_size = 100M/' "$ini"
done
systemctl restart apache2

# Certificado SSL/TLS
certbot --apache -d "$DOMINIO" --non-interactive --agree-tos -m "$CORREO_ADMIN" --redirect || \
  echo "Certbot falló: verifica que el dominio apunte al servidor y repite el comando."

# Cron de Moodle
( crontab -u www-data -l 2>/dev/null; echo "* * * * * /usr/bin/php ${WEBROOT}/admin/cli/cron.php >/dev/null" ) | crontab -u www-data -

echo "Listo. Abre https://${DOMINIO} para completar el asistente de instalación de Moodle."
