# Complementos instalados

| Complemento | Tipo | Versión | Para qué se usa | Origen |
|---|---|---|---|---|
| H5P (incluido en Moodle) | Actividad | `[COMPLETAR]` | Contenido interactivo liviano | Núcleo de Moodle |
| `[COMPLETAR: tema]` | Tema | `[COMPLETAR]` | Identidad institucional | `[COMPLETAR]` |
| `[COMPLETAR: otros]` | | | | |

Registra aquí cualquier complemento adicional, su versión y la URL del directorio de complementos de Moodle.
