# Ajustes aplicados en Moodle

Marca cada ajuste cuando lo apliques y anota la fecha.

## Sitio
- [ ] Idioma por defecto: Español (Colombia).
- [ ] Zona horaria: America/Bogota.
- [ ] Nombre del sitio y nombre corto de la institución.
- [ ] Correo de contacto y correo de notificaciones.

## Seguridad
- [ ] Política de contraseñas (longitud mínima 8, mayúscula, minúscula, número).
- [ ] Bloqueo tras intentos fallidos de ingreso.
- [ ] Protocolo HTTPS obligatorio (`wwwroot` con https).
- [ ] Registro de usuarios deshabilitado (las cuentas las crea el administrador).
- [ ] Datos personales mínimos en el perfil (los estudiantes son menores de edad).

## Acceso móvil
- [ ] Habilitar servicios web (*Administración → Funciones avanzadas*).
- [ ] Habilitar el servicio web móvil (*Administración → Servidor → Móvil*).
- [ ] Permitir descarga de cursos en Moodle App.

## Rendimiento (baja conectividad)
- [ ] Caché de Moodle activada.
- [ ] Límite de tamaño de archivos subidos.
- [ ] Imágenes comprimidas y videos livianos (resolución baja).

## Roles
- [ ] Administrador, docente, estudiante y directivo según la matriz de roles del documento (Tabla 29).

## Copias de respaldo
- [ ] Respaldo diario programado (ver `scripts/respaldo.sh`).
- [ ] Restauración verificada (anotar fecha y resultado en `tests/`).

## Informes
- [ ] Informes de participación y de finalización habilitados para docentes y directivos.
