# Pruebas

| Archivo | Contenido |
|---|---|
| `casos_de_prueba.csv` | Casos del plan de pruebas con columnas de resultado para completar |
| `metricas.csv` | Métricas del desarrollo, metas y valores obtenidos |
| `registro_sprints.md` | Bitácora de sprints: objetivo, incremento, revisión y retrospectiva |
| `plantilla_incidencia.md` | Formato para registrar defectos (o usa los *issues* de GitHub) |
| `evidencias/` | Capturas con el nombre del caso, por ejemplo `PF-01.png` |

Meta: ≥ 90 % de pruebas funcionales superadas antes del piloto.
Porcentaje = pruebas superadas / pruebas ejecutadas × 100.
