# Registro de sprints

Copia el bloque por cada sprint y complétalo en la revisión y la retrospectiva.

## Sprint N (semanas X–Y)
- **Objetivo del sprint:**
- **Historias comprometidas:** HUxx, HUxx
- **Historias terminadas:**
- **Incremento entregado:**
- **Commits / ramas relevantes:**
- **Revisión con el dueño del producto (fecha y observaciones):**
- **Retrospectiva – qué funcionó:**
- **Retrospectiva – qué mejorar:**
- **Acciones para el siguiente sprint:**
- **Objetivo cumplido:** Sí / No

---

## Plan de referencia (Tabla 22 del documento maestro)
| Sprint | Semanas | Objetivo |
|---|---|---|
| 1 | 1–2 | Permisos, consentimientos, instrumentos y visión del producto |
| 2 | 3–4 | Aplicar instrumentos e inventariar la infraestructura |
| 3 | 5–6 | Analizar datos, especificar requisitos y preparar entornos |
| 4 | 7–8 | Diseñar arquitectura, prototipos y estructura pedagógica |
| 5 | 9–10 | Plataforma base, curso plantilla y primer curso |
| 6 | 11–12 | Segundo curso, banco de preguntas y H5P |
| 7 | 13–14 | Tercer curso, respaldos, seguridad y capacitación |
| 8 | 15–16 | Pruebas de usabilidad, ajustes y manual |
| 9 | 17–18 | Inicio del piloto |
| 10 | 19–20 | Fin del piloto y aplicación de SUS, TAM e ICDA |
| 11 | 21–22 | Análisis y ajustes |
| 12 | 23–24 | Informe final y guía de transición |
