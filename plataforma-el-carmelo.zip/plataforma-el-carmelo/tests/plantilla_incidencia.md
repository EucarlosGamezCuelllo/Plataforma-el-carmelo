# Incidencia

- **ID:**
- **Prueba asociada:** (por ejemplo PF-05)
- **Historia / requisito:**
- **Severidad:** Crítica / Mayor / Menor
- **Entorno:** pruebas / producción – dispositivo y navegador o app
- **Pasos para reproducir:**
  1.
  2.
- **Resultado esperado:**
- **Resultado obtenido:**
- **Evidencia (captura):**
- **Estado:** Abierta / En corrección / Resuelta
- **Commit de la corrección:**
