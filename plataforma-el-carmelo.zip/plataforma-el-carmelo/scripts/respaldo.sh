#!/usr/bin/env bash
# Copia de respaldo diaria de Moodle (base de datos + moodledata).
# Programar con cron (como root):
#   0 2 * * * /opt/moodle-scripts/respaldo.sh >> /var/log/respaldo_moodle.log 2>&1
# Las credenciales se leen de ~/.my.cnf (permisos 600) para no escribir claves en este archivo.
set -euo pipefail

DB_NAME="moodle"
DATAROOT="/var/moodledata"
DESTINO="/var/backups/moodle"
RETENCION_DIAS=14
FECHA="$(date +%Y%m%d_%H%M%S)"

mkdir -p "$DESTINO"
echo "[$(date)] Iniciando respaldo..."

# Modo mantenimiento (opcional)
# php /var/www/moodle/admin/cli/maintenance.php --enable

mysqldump --single-transaction --quick "$DB_NAME" | gzip > "$DESTINO/db_${FECHA}.sql.gz"
tar -czf "$DESTINO/moodledata_${FECHA}.tar.gz" -C "$(dirname "$DATAROOT")" "$(basename "$DATAROOT")" \
  --exclude="$(basename "$DATAROOT")/cache" --exclude="$(basename "$DATAROOT")/localcache" \
  --exclude="$(basename "$DATAROOT")/sessions" --exclude="$(basename "$DATAROOT")/temp"

# php /var/www/moodle/admin/cli/maintenance.php --disable

# Retención
find "$DESTINO" -type f -mtime +"$RETENCION_DIAS" -delete
echo "[$(date)] Respaldo terminado: $DESTINO (${FECHA})"
