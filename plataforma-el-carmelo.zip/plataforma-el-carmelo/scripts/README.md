# Scripts

| Script | Función | Prueba asociada |
|---|---|---|
| `respaldo.sh` | Respaldo diario de la base de datos y de `moodledata` con retención de 14 días | HU14 / PS-02 |
| `restaurar.sh` | Restauración de un respaldo (usar primero en pruebas) | PS-02 |
| `plantilla_usuarios.csv` | Plantilla de carga masiva (solo datos **ficticios**) | PF-03 / HU13 |

Para la carga masiva en Moodle: *Administración del sitio → Usuarios → Cuentas → Subir usuarios*.
Las contraseñas de la plantilla son temporales; activa «forzar cambio de contraseña» en el primer ingreso.
**Nunca subas el CSV con usuarios reales** (`.gitignore` bloquea `usuarios_real*.csv`).
