#!/usr/bin/env bash
# Restaura un respaldo de Moodle. USAR PRIMERO EN UN ENTORNO DE PRUEBAS.
# Uso: sudo bash restaurar.sh db_YYYYMMDD_HHMMSS.sql.gz moodledata_YYYYMMDD_HHMMSS.tar.gz
set -euo pipefail

DB_NAME="moodle"
DATAROOT="/var/moodledata"
WEBROOT="/var/www/moodle"

if [[ $# -ne 2 ]]; then echo "Uso: $0 <respaldo_db.sql.gz> <respaldo_moodledata.tar.gz>"; exit 1; fi
DB_FILE="$1"; DATA_FILE="$2"

read -r -p "Esto reemplazará la base '$DB_NAME' y '$DATAROOT'. ¿Continuar? (si/no) " r
[[ "$r" == "si" ]] || { echo "Cancelado."; exit 1; }

php "$WEBROOT/admin/cli/maintenance.php" --enable || true
mysql -e "DROP DATABASE IF EXISTS ${DB_NAME}; CREATE DATABASE ${DB_NAME} DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
gunzip -c "$DB_FILE" | mysql "$DB_NAME"
rm -rf "${DATAROOT:?}"/*
tar -xzf "$DATA_FILE" -C "$(dirname "$DATAROOT")"
chown -R www-data:www-data "$DATAROOT"
php "$WEBROOT/admin/cli/purge_caches.php"
php "$WEBROOT/admin/cli/maintenance.php" --disable || true
echo "Restauración completa. Registra la fecha y el resultado en tests/ (prueba PS-02)."
